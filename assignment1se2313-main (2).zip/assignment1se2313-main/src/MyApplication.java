import models.Point;
import models.Shape;

import java.util.Scanner;

public class MyApplication {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Shape shape = new Shape();

        System.out.println("Enter points for the shape (enter 'done' to finish):");

        while (true) {
            System.out.print("Enter x coordinate (or 'done' to finish): ");
            String input = scanner.next();
            if (input.equalsIgnoreCase("done")) {
                break;
            }

            double x = Double.parseDouble(input);

            System.out.print("Enter y coordinate: ");
            double y = scanner.nextDouble();

            Point point = new Point(x, y);
            shape.addPoint(point);
        }

        if (shape.calculatePerimeter() == 0) {
            System.out.println("No valid shape was created. Exiting.");
            return;
        }

        System.out.println("Perimeter: " + shape.calculatePerimeter());
        System.out.println("Longest side: " + shape.getLongestSide());
        System.out.println("Average side length: " + shape.getAverageSide());

        scanner.close();
    }
}
