package models;

import java.util.ArrayList;

public class Shape {
    private ArrayList<Point> points;

    public Shape() {
        points = new ArrayList<>();
    }

    public void addPoint(Point point) {
        points.add(point);
    }

    public double calculatePerimeter() {
        double perimeter = 0.0;
        for (int i = 0; i < points.size(); i++) {
            Point current = points.get(i);
            Point next = points.get((i + 1) % points.size()); // Замкнутый контур
            perimeter += current.distanceTo(next);
        }
        return perimeter;
    }

    public double getLongestSide() {
        double longest = 0.0;
        for (int i = 0; i < points.size(); i++) {
            Point current = points.get(i);
            Point next = points.get((i + 1) % points.size());
            double distance = current.distanceTo(next);
            if (distance > longest) {
                longest = distance;
            }
        }
        return longest;
    }

    public double getAverageSide() {
        if (points.size() < 2) return 0.0;
        return calculatePerimeter() / points.size();
    }
}
